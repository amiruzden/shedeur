from typing import Union  # Импортируем Union
from Cell import Cell

class Board:

    def __init__(self, cells: list[Cell]) -> None:
        self.cells = cells
    
    def can_move_from(self, cell: Cell) -> list[Cell]:
        if cell.is_king:  # Если шашка — дамка, она может ходить на любое расстояние по диагонали
            return [c for c in self.cells if c.reacheable_from(cell)]
        else:  # Если шашка обычная, она может ходить только на одну клетку вперед
            possible_moves = [c for c in self.cells if c.reacheable_from(cell) and abs(c.coord_x - cell.coord_x) == 1 and abs(c.coord_y - cell.coord_y) == 1]
            possible_captures = [c for c in self.cells if self.can_capture(cell, c)]
            return possible_moves + possible_captures
        
    def can_capture(self, cell_from: Cell, cell_to: Cell) -> bool:
        if abs(cell_to.coord_x - cell_from.coord_x) == 2 and abs(cell_to.coord_y - cell_from.coord_y) == 2:
            middle_x = (cell_to.coord_x + cell_from.coord_x) // 2
            middle_y = (cell_to.coord_y + cell_from.coord_y) // 2
            middle_cell = self.cell_with(middle_x, middle_y)
            if middle_cell.is_occupied and middle_cell.player != cell_from.player:
                return True
        return False

    def cell_with(self, coord_x: int, coord_y: int) -> Cell:
        selection = [c for c in self.cells if c.coord_x == coord_x and c.coord_y == coord_y]
        return selection[0]
    
    def move(self, cell_from: Cell, cell_to: Cell) -> Union[bool, str]:
        if cell_from and cell_to in self.can_move_from(cell_from):
            if self.can_capture(cell_from, cell_to):
                self.handle_capture(cell_from, cell_to)

            cell_from.is_occupied = False
            cell_to.is_occupied = True
            cell_to.player = cell_from.player
            cell_to.is_king = cell_from.is_king
            cell_from.player = None

            if not cell_to.is_king and ((cell_to.coord_x == 1 and cell_to.player == 2) or (cell_to.coord_x == 8 and cell_to.player == 1)):
                cell_to.is_king = True

            winner = self.check_winner()  # Проверка победителя после хода
            if winner:
                return winner
            return True
        else:
            return False
        
    def handle_capture(self, cell_from: Cell, cell_to: Cell) -> None:
        middle_x = (cell_to.coord_x + cell_from.coord_x) // 2
        middle_y = (cell_to.coord_y + cell_from.coord_y) // 2
        middle_cell = self.cell_with(middle_x, middle_y)
        if middle_cell.is_occupied and middle_cell.player != cell_from.player:
            middle_cell.is_occupied = False
            middle_cell.player = None

    def check_winner(self):
        white_left = any(cell.is_occupied and cell.player == 1 for cell in self.cells)
        black_left = any(cell.is_occupied and cell.player == 2 for cell in self.cells)

        if not white_left:
            return "Черные"
        elif not black_left:
            return "Белые"
        else:
            return None


# Обновленная функция для создания доски с шашками обоих игроков
def three_x_three_board() -> Board:
    cells = []
    for i in range(1, 9):
        for j in range(1, 9):
            if i < 4:
                # шашки первого игрока
                cells.append(Cell(coord_x=i, coord_y=j, is_occupied=True, player=1))
            elif i > 5:
                # шашки второго игрока
                cells.append(Cell(coord_x=i, coord_y=j, is_occupied=True, player=2, is_king=False))
            else:
                # пустые клетки
                cells.append(Cell(coord_x=i, coord_y=j, is_occupied=False, player=None, is_king=False))

    return Board(cells=cells)
