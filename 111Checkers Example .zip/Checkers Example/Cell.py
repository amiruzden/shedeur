from dataclasses import dataclass
from typing import Self

@dataclass
class Cell:
    coord_x: int
    coord_y: int
    is_occupied: bool
    player: int = None  # атрибут для хранения инфы об игроке
    color: str = None   # атрибут для хранения цвета шашки
    is_king: bool = False  # атрибут для хранения состояния дамки
    
    def __init__(self, coord_x: int, coord_y: int, is_occupied: bool, player: int = None, is_king: bool = False):
        self.coord_x = coord_x
        self.coord_y = coord_y
        self.is_occupied = is_occupied
        self.player = player
        self.is_king = is_king
    
    # обновленный метод, учитывающий игрока и тип шашки
    def reacheable_from(self, other: Self) -> bool:
        if self.is_occupied: 
            return False
        # Если шашка - дамка, она может ходить в любом направлении по диагонали
        if other.is_king:
            return abs(self.coord_x - other.coord_x) == abs(self.coord_y - other.coord_y)
        # обычная шашка первого игрока может двигаться только вниз
        if other.player == 1 and self.coord_x == other.coord_x + 1 and abs(self.coord_y - other.coord_y) == 1:
            return True
        # обычная шашка второго игрока может двигаться только вверх
        if other.player == 2 and self.coord_x == other.coord_x - 1 and abs(self.coord_y - other.coord_y) == 1:
            return True
        if abs(self.coord_x - other.coord_x) == 2 and abs(self.coord_y - other.coord_y) == 2:
            return True
        return False
